// +build OMIT

package main

import "fmt"

// var 变量名 类型
var c, python, java bool

func main() {
	var i int
	fmt.Println(i, c, python, java)
}
